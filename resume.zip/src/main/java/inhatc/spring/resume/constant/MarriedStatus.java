package inhatc.spring.resume.constant;

public enum MarriedStatus {

    Single, Married
}
