package inhatc.spring.resume.constant;

public enum MilitaryStatus {

    Unfulfilled, Fulfilled, Exempted
}
