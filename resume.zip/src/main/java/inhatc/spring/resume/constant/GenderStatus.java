package inhatc.spring.resume.constant;

public enum GenderStatus {

    Male, Female
}
