package inhatc.spring.resume.constant;

public enum Role {
    USER, ADMIN
}
